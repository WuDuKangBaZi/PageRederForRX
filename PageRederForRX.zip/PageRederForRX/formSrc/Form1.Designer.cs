﻿namespace PageRederForRX
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainListBox = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ChartLayoutListBox = new System.Windows.Forms.ListBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.shuxingDataGrid = new System.Windows.Forms.DataGridView();
            this.IBillId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vOrgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cvID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vCheckType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vHint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vExPValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vDicID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIOrderID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vtestvalue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel23 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.vApiId = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lockbtn = new System.Windows.Forms.Button();
            this.savethis = new System.Windows.Forms.Button();
            this.recbtn = new System.Windows.Forms.Button();
            this.combtn = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.vID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vDefault = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vLable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IOrderID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vgroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vFieldCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vMainLable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vTop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vLeft = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vWidth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vHeight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vGroundColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vfrmtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vIsShow = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vChange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vtexttype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button4 = new System.Windows.Forms.Button();
            this.dataLoadBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shuxingDataGrid)).BeginInit();
            this.panel23.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.rightPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel22.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataLoadBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // MainListBox
            // 
            this.MainListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainListBox.FormattingEnabled = true;
            this.MainListBox.ItemHeight = 12;
            this.MainListBox.Location = new System.Drawing.Point(3, 17);
            this.MainListBox.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.MainListBox.Name = "MainListBox";
            this.MainListBox.Size = new System.Drawing.Size(194, 447);
            this.MainListBox.TabIndex = 0;
            this.MainListBox.SelectedIndexChanged += new System.EventHandler(this.manListSelect);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 817);
            this.panel1.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox7);
            this.panel3.Controls.Add(this.groupBox8);
            this.panel3.Controls.Add(this.groupBox6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 817);
            this.panel3.TabIndex = 1;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.MainListBox);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 100);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 467);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "表头";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button1);
            this.groupBox8.Controls.Add(this.textBox11);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 100);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "输入单据号";
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.Location = new System.Drawing.Point(3, 77);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 20);
            this.button1.TabIndex = 4;
            this.button1.Text = "加载数据";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // textBox11
            // 
            this.textBox11.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox11.Location = new System.Drawing.Point(3, 17);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(194, 21);
            this.textBox11.TabIndex = 3;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ChartLayoutListBox);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox6.Location = new System.Drawing.Point(0, 567);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 250);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "表身";
            // 
            // ChartLayoutListBox
            // 
            this.ChartLayoutListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChartLayoutListBox.FormattingEnabled = true;
            this.ChartLayoutListBox.ItemHeight = 12;
            this.ChartLayoutListBox.Location = new System.Drawing.Point(3, 17);
            this.ChartLayoutListBox.Name = "ChartLayoutListBox";
            this.ChartLayoutListBox.Size = new System.Drawing.Size(194, 230);
            this.ChartLayoutListBox.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.groupBox2);
            this.panel5.Controls.Add(this.rightPanel);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(200, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1065, 817);
            this.panel5.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.mainPanel);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(180, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(585, 817);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "布局预览界面--不支持操作";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tabControl1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 517);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(579, 297);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "单据相关信息修改";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 17);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(573, 277);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.shuxingDataGrid);
            this.tabPage1.Controls.Add(this.panel23);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(565, 251);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "单据属性检测";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // shuxingDataGrid
            // 
            this.shuxingDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.shuxingDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IBillId,
            this.vOrgID,
            this.cvID,
            this.vCheckType,
            this.vHint,
            this.vExPValue,
            this.vDicID,
            this.cIOrderID,
            this.vtestvalue,
            this.vRemarks});
            this.shuxingDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shuxingDataGrid.Location = new System.Drawing.Point(3, 39);
            this.shuxingDataGrid.Name = "shuxingDataGrid";
            this.shuxingDataGrid.ReadOnly = true;
            this.shuxingDataGrid.RowTemplate.Height = 23;
            this.shuxingDataGrid.Size = new System.Drawing.Size(559, 209);
            this.shuxingDataGrid.TabIndex = 1;
            this.shuxingDataGrid.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.shuxing_doubleClick);
            // 
            // IBillId
            // 
            this.IBillId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IBillId.DataPropertyName = "IBillId";
            this.IBillId.HeaderText = "单据号";
            this.IBillId.Name = "IBillId";
            this.IBillId.ReadOnly = true;
            this.IBillId.Visible = false;
            // 
            // vOrgID
            // 
            this.vOrgID.DataPropertyName = "vOrgID";
            this.vOrgID.HeaderText = "vOrgID";
            this.vOrgID.Name = "vOrgID";
            this.vOrgID.ReadOnly = true;
            this.vOrgID.Visible = false;
            // 
            // cvID
            // 
            this.cvID.DataPropertyName = "vID";
            this.cvID.HeaderText = "标签";
            this.cvID.Name = "cvID";
            this.cvID.ReadOnly = true;
            // 
            // vCheckType
            // 
            this.vCheckType.DataPropertyName = "vCheckType";
            this.vCheckType.HeaderText = "判断类型";
            this.vCheckType.Name = "vCheckType";
            this.vCheckType.ReadOnly = true;
            // 
            // vHint
            // 
            this.vHint.DataPropertyName = "vHint";
            this.vHint.HeaderText = "标题";
            this.vHint.Name = "vHint";
            this.vHint.ReadOnly = true;
            // 
            // vExPValue
            // 
            this.vExPValue.DataPropertyName = "vExPValue";
            this.vExPValue.HeaderText = "判断逻辑";
            this.vExPValue.Name = "vExPValue";
            this.vExPValue.ReadOnly = true;
            // 
            // vDicID
            // 
            this.vDicID.DataPropertyName = "vDicID";
            this.vDicID.HeaderText = "vDicID";
            this.vDicID.Name = "vDicID";
            this.vDicID.ReadOnly = true;
            this.vDicID.Visible = false;
            // 
            // cIOrderID
            // 
            this.cIOrderID.DataPropertyName = "IOrderID";
            this.cIOrderID.HeaderText = "排序";
            this.cIOrderID.Name = "cIOrderID";
            this.cIOrderID.ReadOnly = true;
            // 
            // vtestvalue
            // 
            this.vtestvalue.DataPropertyName = "vtestvalue";
            this.vtestvalue.HeaderText = "测试数据";
            this.vtestvalue.Name = "vtestvalue";
            this.vtestvalue.ReadOnly = true;
            // 
            // vRemarks
            // 
            this.vRemarks.DataPropertyName = "vRemarks";
            this.vRemarks.HeaderText = "备注";
            this.vRemarks.Name = "vRemarks";
            this.vRemarks.ReadOnly = true;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.button2);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel23.Location = new System.Drawing.Point(3, 3);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(559, 36);
            this.panel23.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(20, 10);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "加载数据";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(565, 251);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "属性信息";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel1);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.vApiId);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(559, 209);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "com接口配置";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(306, 60);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(181, 21);
            this.textBox12.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(247, 69);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 15;
            this.label17.Text = "接口备注";
            // 
            // vApiId
            // 
            this.vApiId.Location = new System.Drawing.Point(118, 66);
            this.vApiId.Name = "vApiId";
            this.vApiId.ReadOnly = true;
            this.vApiId.Size = new System.Drawing.Size(100, 21);
            this.vApiId.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(21, 142);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 13;
            this.label18.Text = "接口id";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 21);
            this.button3.TabIndex = 12;
            this.button3.Text = "新增";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // mainPanel
            // 
            this.mainPanel.AutoScroll = true;
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.mainPanel.Location = new System.Drawing.Point(3, 17);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(579, 500);
            this.mainPanel.TabIndex = 2;
            // 
            // rightPanel
            // 
            this.rightPanel.Controls.Add(this.groupBox1);
            this.rightPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightPanel.Location = new System.Drawing.Point(765, 0);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(300, 817);
            this.rightPanel.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel22);
            this.groupBox1.Controls.Add(this.panel19);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.panel21);
            this.groupBox1.Controls.Add(this.panel20);
            this.groupBox1.Controls.Add(this.panel18);
            this.groupBox1.Controls.Add(this.panel17);
            this.groupBox1.Controls.Add(this.panel16);
            this.groupBox1.Controls.Add(this.panel15);
            this.groupBox1.Controls.Add(this.panel14);
            this.groupBox1.Controls.Add(this.panel13);
            this.groupBox1.Controls.Add(this.panel12);
            this.groupBox1.Controls.Add(this.panel11);
            this.groupBox1.Controls.Add(this.panel10);
            this.groupBox1.Controls.Add(this.panel9);
            this.groupBox1.Controls.Add(this.panel8);
            this.groupBox1.Controls.Add(this.panel7);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 817);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "单据字段属性修改";
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.flowLayoutPanel1);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(3, 625);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(294, 100);
            this.panel22.TabIndex = 18;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.lockbtn);
            this.flowLayoutPanel1.Controls.Add(this.savethis);
            this.flowLayoutPanel1.Controls.Add(this.recbtn);
            this.flowLayoutPanel1.Controls.Add(this.combtn);
            this.flowLayoutPanel1.Controls.Add(this.button6);
            this.flowLayoutPanel1.Controls.Add(this.button7);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(294, 100);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // lockbtn
            // 
            this.lockbtn.Location = new System.Drawing.Point(13, 3);
            this.lockbtn.Name = "lockbtn";
            this.lockbtn.Size = new System.Drawing.Size(75, 23);
            this.lockbtn.TabIndex = 0;
            this.lockbtn.Text = "锁定";
            this.lockbtn.UseVisualStyleBackColor = true;
            this.lockbtn.Click += new System.EventHandler(this.lockbtn_Click);
            // 
            // savethis
            // 
            this.savethis.Enabled = false;
            this.savethis.Location = new System.Drawing.Point(106, 3);
            this.savethis.Margin = new System.Windows.Forms.Padding(15, 3, 3, 3);
            this.savethis.Name = "savethis";
            this.savethis.Size = new System.Drawing.Size(75, 23);
            this.savethis.TabIndex = 1;
            this.savethis.Text = "保存更改";
            this.savethis.UseVisualStyleBackColor = true;
            this.savethis.Click += new System.EventHandler(this.savethis_Click);
            // 
            // recbtn
            // 
            this.recbtn.Location = new System.Drawing.Point(199, 3);
            this.recbtn.Margin = new System.Windows.Forms.Padding(15, 3, 3, 3);
            this.recbtn.Name = "recbtn";
            this.recbtn.Size = new System.Drawing.Size(75, 23);
            this.recbtn.TabIndex = 2;
            this.recbtn.Text = "放弃锁定";
            this.recbtn.UseVisualStyleBackColor = true;
            this.recbtn.Click += new System.EventHandler(this.recbtn_Click);
            // 
            // combtn
            // 
            this.combtn.Location = new System.Drawing.Point(13, 32);
            this.combtn.Name = "combtn";
            this.combtn.Size = new System.Drawing.Size(75, 23);
            this.combtn.TabIndex = 3;
            this.combtn.Text = "com接口";
            this.combtn.UseVisualStyleBackColor = true;
            this.combtn.Visible = false;
            this.combtn.Click += new System.EventHandler(this.combtn_Click);
            // 
            // button6
            // 
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(106, 32);
            this.button6.Margin = new System.Windows.Forms.Padding(15, 3, 3, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 4;
            this.button6.Text = "数据检测";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(199, 32);
            this.button7.Margin = new System.Windows.Forms.Padding(15, 3, 3, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 5;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.textBox10);
            this.panel19.Controls.Add(this.label14);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(3, 587);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(294, 38);
            this.panel19.TabIndex = 17;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(74, 8);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(211, 21);
            this.textBox10.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "备注显示";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(3, 549);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(294, 38);
            this.panel4.TabIndex = 16;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(74, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(211, 21);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "组别";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.comboBox1);
            this.panel21.Controls.Add(this.label16);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(3, 511);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(294, 38);
            this.panel21.TabIndex = 15;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(74, 8);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(211, 20);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 11);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "是否显示";
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.textBox15);
            this.panel20.Controls.Add(this.label15);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(3, 473);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(294, 38);
            this.panel20.TabIndex = 14;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(74, 8);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(211, 21);
            this.textBox15.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "默认值";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.textBox13);
            this.panel18.Controls.Add(this.label13);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(3, 435);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(294, 38);
            this.panel18.TabIndex = 12;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(74, 8);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(211, 21);
            this.textBox13.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "主显示信息";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.comboBox4);
            this.panel17.Controls.Add(this.label12);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(3, 397);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(294, 38);
            this.panel17.TabIndex = 11;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "是",
            "否"});
            this.comboBox4.Location = new System.Drawing.Point(74, 6);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(211, 20);
            this.comboBox4.TabIndex = 2;
            this.comboBox4.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "文本类型";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.comboBox3);
            this.panel16.Controls.Add(this.label11);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(3, 359);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(294, 38);
            this.panel16.TabIndex = 10;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "是",
            "否"});
            this.comboBox3.Location = new System.Drawing.Point(74, 8);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(211, 20);
            this.comboBox3.TabIndex = 2;
            this.comboBox3.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "编码转换";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.comboBox2);
            this.panel15.Controls.Add(this.label10);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(3, 321);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(294, 38);
            this.panel15.TabIndex = 9;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(74, 6);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(211, 20);
            this.comboBox2.TabIndex = 2;
            this.comboBox2.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "弹框类型";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.textBox9);
            this.panel14.Controls.Add(this.label9);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(3, 283);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(294, 38);
            this.panel14.TabIndex = 8;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(74, 8);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(211, 21);
            this.textBox9.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "排序";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.textBox8);
            this.panel13.Controls.Add(this.label8);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(3, 245);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(294, 38);
            this.panel13.TabIndex = 7;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(74, 8);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(211, 21);
            this.textBox8.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "背景颜色";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.textBox7);
            this.panel12.Controls.Add(this.label7);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(3, 207);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(294, 38);
            this.panel12.TabIndex = 6;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(74, 8);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(211, 21);
            this.textBox7.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "字体颜色";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.textBox6);
            this.panel11.Controls.Add(this.label6);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(3, 169);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(294, 38);
            this.panel11.TabIndex = 5;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(74, 8);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(211, 21);
            this.textBox6.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "高度";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.textBox5);
            this.panel10.Controls.Add(this.label5);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(3, 131);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(294, 38);
            this.panel10.TabIndex = 4;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(74, 8);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(211, 21);
            this.textBox5.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "宽度";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.textBox4);
            this.panel9.Controls.Add(this.label4);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(3, 93);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(294, 38);
            this.panel9.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(74, 8);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(211, 21);
            this.textBox4.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "上边距";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.textBox3);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(3, 55);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(294, 38);
            this.panel8.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(74, 8);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(211, 21);
            this.textBox3.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "左边距";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.textBox2);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(3, 17);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(294, 38);
            this.panel7.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(74, 8);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(211, 21);
            this.textBox2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "字段标识";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.dataGridView1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(180, 817);
            this.panel6.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vID,
            this.vDefault,
            this.vLable,
            this.IOrderID,
            this.vgroup,
            this.vFieldCode,
            this.vMainLable,
            this.vTop,
            this.vLeft,
            this.vWidth,
            this.vHeight,
            this.vColor,
            this.vGroundColor,
            this.vfrmtype,
            this.vIsShow,
            this.vChange,
            this.vtexttype});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(180, 817);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.doubleCilck);
            // 
            // vID
            // 
            this.vID.DataPropertyName = "vID";
            this.vID.HeaderText = "vID";
            this.vID.Name = "vID";
            this.vID.ReadOnly = true;
            this.vID.Visible = false;
            // 
            // vDefault
            // 
            this.vDefault.DataPropertyName = "vDefault";
            this.vDefault.HeaderText = "vDefault";
            this.vDefault.Name = "vDefault";
            this.vDefault.ReadOnly = true;
            this.vDefault.Visible = false;
            // 
            // vLable
            // 
            this.vLable.DataPropertyName = "vLable";
            this.vLable.HeaderText = "vLable";
            this.vLable.Name = "vLable";
            this.vLable.ReadOnly = true;
            this.vLable.Visible = false;
            // 
            // IOrderID
            // 
            this.IOrderID.DataPropertyName = "IOrderID";
            this.IOrderID.HeaderText = "IOrderID";
            this.IOrderID.Name = "IOrderID";
            this.IOrderID.ReadOnly = true;
            this.IOrderID.Visible = false;
            // 
            // vgroup
            // 
            this.vgroup.DataPropertyName = "vgroup";
            this.vgroup.HeaderText = "vgroup";
            this.vgroup.Name = "vgroup";
            this.vgroup.ReadOnly = true;
            this.vgroup.Visible = false;
            // 
            // vFieldCode
            // 
            this.vFieldCode.DataPropertyName = "vFieldCode";
            this.vFieldCode.HeaderText = "字段名称";
            this.vFieldCode.Name = "vFieldCode";
            this.vFieldCode.ReadOnly = true;
            this.vFieldCode.ToolTipText = "双击加载数据";
            this.vFieldCode.Visible = false;
            // 
            // vMainLable
            // 
            this.vMainLable.DataPropertyName = "vMainLable";
            this.vMainLable.HeaderText = "字段";
            this.vMainLable.Name = "vMainLable";
            this.vMainLable.ReadOnly = true;
            // 
            // vTop
            // 
            this.vTop.DataPropertyName = "vTop";
            this.vTop.HeaderText = "vTop";
            this.vTop.Name = "vTop";
            this.vTop.ReadOnly = true;
            this.vTop.Visible = false;
            // 
            // vLeft
            // 
            this.vLeft.DataPropertyName = "vLeft";
            this.vLeft.HeaderText = "vLeft";
            this.vLeft.Name = "vLeft";
            this.vLeft.ReadOnly = true;
            this.vLeft.Visible = false;
            // 
            // vWidth
            // 
            this.vWidth.DataPropertyName = "vWidth";
            this.vWidth.HeaderText = "vWidth";
            this.vWidth.Name = "vWidth";
            this.vWidth.ReadOnly = true;
            this.vWidth.Visible = false;
            // 
            // vHeight
            // 
            this.vHeight.DataPropertyName = "vHeight";
            this.vHeight.HeaderText = "vHeight";
            this.vHeight.Name = "vHeight";
            this.vHeight.ReadOnly = true;
            this.vHeight.Visible = false;
            // 
            // vColor
            // 
            this.vColor.DataPropertyName = "vColor";
            this.vColor.HeaderText = "vColor";
            this.vColor.Name = "vColor";
            this.vColor.ReadOnly = true;
            this.vColor.Visible = false;
            // 
            // vGroundColor
            // 
            this.vGroundColor.DataPropertyName = "vGroundColor";
            this.vGroundColor.HeaderText = "vGroundColor";
            this.vGroundColor.Name = "vGroundColor";
            this.vGroundColor.ReadOnly = true;
            this.vGroundColor.Visible = false;
            // 
            // vfrmtype
            // 
            this.vfrmtype.DataPropertyName = "vfrmtype";
            this.vfrmtype.HeaderText = "vfrmtype";
            this.vfrmtype.Name = "vfrmtype";
            this.vfrmtype.ReadOnly = true;
            this.vfrmtype.Visible = false;
            // 
            // vIsShow
            // 
            this.vIsShow.DataPropertyName = "vIsShow";
            this.vIsShow.HeaderText = "vIsShow";
            this.vIsShow.Name = "vIsShow";
            this.vIsShow.ReadOnly = true;
            this.vIsShow.Visible = false;
            // 
            // vChange
            // 
            this.vChange.DataPropertyName = "vChange";
            this.vChange.HeaderText = "vChange";
            this.vChange.Name = "vChange";
            this.vChange.ReadOnly = true;
            this.vChange.Visible = false;
            // 
            // vtexttype
            // 
            this.vtexttype.DataPropertyName = "vtexttype";
            this.vtexttype.HeaderText = "vtexttype";
            this.vtexttype.Name = "vtexttype";
            this.vtexttype.ReadOnly = true;
            this.vtexttype.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 321F));
            this.tableLayoutPanel1.Controls.Add(this.button4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button3, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(553, 34);
            this.tableLayoutPanel1.TabIndex = 17;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(84, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 13;
            this.button4.Text = "保存";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataLoadBindingSource
            // 
            this.dataLoadBindingSource.DataSource = typeof(PageRederForRX.src.Function.DataLoad);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(565, 251);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "分页3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1265, 817);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::PageRederForRX.Properties.Settings.Default, "MainFormName", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = global::PageRederForRX.Properties.Settings.Default.MainFormName;
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.shuxingDataGrid)).EndInit();
            this.panel23.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.rightPanel.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataLoadBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListBox MainListBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.BindingSource dataLoadBindingSource;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button lockbtn;
        private System.Windows.Forms.Button savethis;
        private System.Windows.Forms.Button recbtn;
        private System.Windows.Forms.Button combtn;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView shuxingDataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn IBillId;
        private System.Windows.Forms.DataGridViewTextBoxColumn vOrgID;
        private System.Windows.Forms.DataGridViewTextBoxColumn cvID;
        private System.Windows.Forms.DataGridViewTextBoxColumn vCheckType;
        private System.Windows.Forms.DataGridViewTextBoxColumn vHint;
        private System.Windows.Forms.DataGridViewTextBoxColumn vExPValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn vDicID;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIOrderID;
        private System.Windows.Forms.DataGridViewTextBoxColumn vtestvalue;
        private System.Windows.Forms.DataGridViewTextBoxColumn vRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn vID;
        private System.Windows.Forms.DataGridViewTextBoxColumn vDefault;
        private System.Windows.Forms.DataGridViewTextBoxColumn vLable;
        private System.Windows.Forms.DataGridViewTextBoxColumn IOrderID;
        private System.Windows.Forms.DataGridViewTextBoxColumn vgroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn vFieldCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn vMainLable;
        private System.Windows.Forms.DataGridViewTextBoxColumn vTop;
        private System.Windows.Forms.DataGridViewTextBoxColumn vLeft;
        private System.Windows.Forms.DataGridViewTextBoxColumn vWidth;
        private System.Windows.Forms.DataGridViewTextBoxColumn vHeight;
        private System.Windows.Forms.DataGridViewTextBoxColumn vColor;
        private System.Windows.Forms.DataGridViewTextBoxColumn vGroundColor;
        private System.Windows.Forms.DataGridViewTextBoxColumn vfrmtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn vIsShow;
        private System.Windows.Forms.DataGridViewTextBoxColumn vChange;
        private System.Windows.Forms.DataGridViewTextBoxColumn vtexttype;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ListBox ChartLayoutListBox;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox vApiId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage tabPage3;
    }
}

