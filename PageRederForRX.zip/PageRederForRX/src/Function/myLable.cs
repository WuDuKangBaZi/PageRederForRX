﻿using System.Windows.Forms;

namespace PageRederForRX.src.Function
{
    class myLable : Label
    {
       public string inputName { get; set; }
    }
}
